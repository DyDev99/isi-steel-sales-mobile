enum SalesOrderStatus { pending, confirmed }
