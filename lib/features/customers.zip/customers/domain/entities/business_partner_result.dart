// =============================================================================
// business_partner_result.dart
//
// What comes back from `POST /api/v1/mobile/customers/business-partner`.
//
// The interesting part is [messages]. A SAP BAPI does not fail with an HTTP
// status — it returns 200 with a return table whose rows carry the verdict, so
// a call can be transport-successful and business-failed at the same time. The
// repository therefore inspects [hasError] rather than trusting the status code
// alone, and the rep sees SAP's own wording instead of "something went wrong".
// =============================================================================

import 'package:equatable/equatable.dart';

/// Severity of one SAP return row. `TYPE` in the BAPI structure.
enum SapMessageType {
  success, // S
  info, // I
  warning, // W
  error, // E
  abort, // A
  exit, // X
  unknown;

  static SapMessageType fromCode(String? code) =>
      switch (code?.trim().toUpperCase()) {
        'S' => SapMessageType.success,
        'I' => SapMessageType.info,
        'W' => SapMessageType.warning,
        'E' => SapMessageType.error,
        'A' => SapMessageType.abort,
        'X' => SapMessageType.exit,
        _ => SapMessageType.unknown,
      };

  /// `A` and `X` are terminated the unit of work; they are errors with a
  /// different name, and treating them as anything softer would report a
  /// registration as accepted when nothing was written.
  bool get isFailure =>
      this == SapMessageType.error ||
      this == SapMessageType.abort ||
      this == SapMessageType.exit;
}

/// One row of SAP's `BAPIRET2` return table.
class SapReturnMessage extends Equatable {
  const SapReturnMessage({
    required this.type,
    required this.message,
    this.id = '',
    this.number = '',
    this.field = '',
  });

  final SapMessageType type;
  final String message;

  /// Message class (`ID`) and number — together they identify the message in
  /// SE91, which is what an SAP consultant will ask for when a rep reports a
  /// rejection nobody can reproduce.
  final String id;
  final String number;

  /// The offending field, when SAP names one. Used to route the error back to
  /// the wizard step that owns it instead of showing a banner.
  final String field;

  bool get isError => type.isFailure;

  /// `ZBP/041`-style reference for logs and support tickets.
  String get code => id.isEmpty ? '' : '$id/$number';

  @override
  List<Object?> get props => [type, message, id, number, field];
}

class BusinessPartnerResult extends Equatable {
  const BusinessPartnerResult({
    this.customerNumber = '',
    this.partnerNumber = '',
    this.submittedToSap = false,
    this.messages = const [],
  });

  /// SAP customer number from the number range. Empty when the record was
  /// parked rather than pushed, or when SAP rejected it.
  final String customerNumber;

  /// BP number, when the middleware reports it separately from the customer
  /// number. Often the same value; kept apart because in an Extend-Customer
  /// scenario they are not.
  final String partnerNumber;

  final bool submittedToSap;
  final List<SapReturnMessage> messages;

  /// True when SAP actually created the partner.
  ///
  /// Requires a customer number *and* no error rows: a middleware that echoes
  /// the request will happily return a blank number next to an error, and
  /// either signal alone has been enough to make a client claim success.
  bool get isCreated => customerNumber.isNotEmpty && !hasError;

  bool get hasError => messages.any((m) => m.isError);

  List<SapReturnMessage> get errors =>
      messages.where((m) => m.isError).toList(growable: false);

  /// The first error, or the first message of any kind, worded for the rep.
  String? get primaryMessage {
    if (messages.isEmpty) return null;
    return (errors.isNotEmpty ? errors.first : messages.first).message;
  }

  /// Errors keyed by the SAP field they name, for per-field display.
  Map<String, String> get fieldErrors => {
        for (final e in errors)
          if (e.field.isNotEmpty) e.field: e.message,
      };

  @override
  List<Object?> get props =>
      [customerNumber, partnerNumber, submittedToSap, messages];
}
