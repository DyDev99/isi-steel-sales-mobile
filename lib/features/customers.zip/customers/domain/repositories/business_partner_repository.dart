import 'package:isi_steel_sales_mobile/core/utils/typedefs.dart';
import 'package:isi_steel_sales_mobile/features/customers/domain/entities/business_partner_request.dart';
import 'package:isi_steel_sales_mobile/features/customers/domain/entities/business_partner_result.dart';

/// The one door to `/api/v1/mobile/customers/business-partner`.
///
/// Deliberately separate from `CustomerSyncRepository`. That repository owns
/// the multi-call server-draft protocol (create draft → patch → submit); this
/// endpoint replaces all three with a single write, and folding one into the
/// other would leave a repository whose two halves disagree about whether a
/// draft id exists.
abstract class BusinessPartnerRepository {
  /// Sends the registration. `Commit: true`, so a success means SAP wrote it.
  ResultFuture<BusinessPartnerResult> createBusinessPartner(
    BusinessPartnerRequest request,
  );

  /// Runs the same payload with `Commit: false`.
  ///
  /// SAP validates and rolls back, so this answers "would this be accepted?"
  /// without creating anything. Worth a call before submit: the wizard can
  /// only check what the app knows, and half of what SAP rejects — a payment
  /// term not open for the sales org, a customer group the division does not
  /// carry — is invisible from the phone.
  ResultFuture<BusinessPartnerResult> validateBusinessPartner(
    BusinessPartnerRequest request,
  );
}
