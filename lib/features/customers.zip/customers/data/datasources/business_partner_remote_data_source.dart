// =============================================================================
// business_partner_remote_data_source.dart
//
// The single network call for SAP BP registration.
//
// Replaces the three-call server-draft protocol (`POST draft`, `POST update`,
// `POST submit`) that `AddCustomerBloc` currently drives. That protocol needed
// a `serverDraftId` before the rep could type anything, which is why the
// wizard's first action is `OpenServerDraft` and why the primary button is
// disabled until it returns. With one write there is no id to obtain and no
// reason to be online before submit — see the wiring notes.
// =============================================================================

import 'package:dio/dio.dart';
import 'package:isi_steel_sales_mobile/core/errors/exceptions.dart';
import 'package:isi_steel_sales_mobile/features/customers/data/models/business_partner_request_model.dart';
import 'package:isi_steel_sales_mobile/features/customers/data/models/business_partner_response_model.dart';

abstract class BusinessPartnerRemoteDataSource {
  Future<BusinessPartnerResponseModel> createBusinessPartner(
    BusinessPartnerRequestModel request,
  );
}

class BusinessPartnerRemoteDataSourceImpl
    implements BusinessPartnerRemoteDataSource {
  const BusinessPartnerRemoteDataSourceImpl(this._client);

  /// The authed client from `core/network/`. Base URL, auth header and the
  /// redacting logger come from there; nothing about credentials belongs here.
  final Dio _client;

  static const String endpoint = '/api/v1/mobile/customers/business-partner';

  /// SAP BP creation runs synchronously through the middleware and regularly
  /// takes longer than a list fetch. The default client timeout is tuned for
  /// reads, and inheriting it means the rep sees a timeout for a registration
  /// that SAP went on to complete — the worst outcome available, because the
  /// obvious response is to try again and create a duplicate.
  static const Duration _writeTimeout = Duration(seconds: 60);

  @override
  Future<BusinessPartnerResponseModel> createBusinessPartner(
    BusinessPartnerRequestModel request,
  ) async {
    try {
      final response = await _client.post<dynamic>(
        endpoint,
        data: request.toJson(),
        options: Options(
          receiveTimeout: _writeTimeout,
          sendTimeout: _writeTimeout,
          // Non-2xx is handled below rather than thrown as a transport error,
          // because this endpoint returns SAP's return table on 400 too and
          // that table is the only place the reason is written.
          validateStatus: (status) => status != null && status < 500,
        ),
      );

      final data = response.data;
      if (data is! Map) {
        throw ServerException(
          message: 'Unexpected response shape from $endpoint',
          statusCode: response.statusCode?.toString() ?? '200',
        );
      }

      final result = BusinessPartnerResponseModel.fromJson(
        Map<String, dynamic>.from(data),
      );

      // A 4xx with no parseable message would otherwise surface as a silent
      // success with an empty customer number.
      final status = response.statusCode ?? 200;
      if (status >= 400 && !result.hasError) {
        throw ServerException(
          message: 'Registration rejected by the server',
          statusCode: status.toString(),
        );
      }

      return result;
    } on DioException catch (e) {
      throw ServerException(
        message: _describe(e),
        statusCode: e.response?.statusCode?.toString() ?? '000',
      );
    }
  }

  /// Turns a Dio failure into something a rep can act on.
  ///
  /// The timeout cases are named explicitly because the action differs: on a
  /// send timeout nothing reached SAP and retrying is safe, while on a receive
  /// timeout the write may have landed and the rep should check the customer
  /// list before re-submitting.
  String _describe(DioException e) {
    final serverMessage = e.response?.data;
    if (serverMessage is Map) {
      final m = serverMessage['message'] ?? serverMessage['error'];
      if (m != null && m.toString().isNotEmpty) return m.toString();
    }
    return switch (e.type) {
      DioExceptionType.sendTimeout ||
      DioExceptionType.connectionTimeout =>
        'Could not reach the server. Nothing was submitted.',
      DioExceptionType.receiveTimeout =>
        'The server did not answer in time. Check the customer list before '
            'submitting again.',
      DioExceptionType.connectionError =>
        'No connection. The registration will be sent when you are back '
            'online.',
      _ => e.message ?? 'Registration failed',
    };
  }
}
