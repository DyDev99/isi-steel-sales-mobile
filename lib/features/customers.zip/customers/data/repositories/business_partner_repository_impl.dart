import 'package:dartz/dartz.dart';
import 'package:isi_steel_sales_mobile/core/errors/exceptions.dart';
import 'package:isi_steel_sales_mobile/core/errors/failures.dart';
import 'package:isi_steel_sales_mobile/core/utils/typedefs.dart';
import 'package:isi_steel_sales_mobile/features/customers/data/datasources/business_partner_remote_data_source.dart';
import 'package:isi_steel_sales_mobile/features/customers/data/models/business_partner_request_model.dart';
import 'package:isi_steel_sales_mobile/features/customers/domain/entities/business_partner_request.dart';
import 'package:isi_steel_sales_mobile/features/customers/domain/entities/business_partner_result.dart';
import 'package:isi_steel_sales_mobile/features/customers/domain/repositories/business_partner_repository.dart';

class BusinessPartnerRepositoryImpl implements BusinessPartnerRepository {
  const BusinessPartnerRepositoryImpl(this._remote);

  final BusinessPartnerRemoteDataSource _remote;

  @override
  ResultFuture<BusinessPartnerResult> createBusinessPartner(
    BusinessPartnerRequest request,
  ) =>
      _send(request.copyWith(commit: true, submitToSap: true));

  @override
  ResultFuture<BusinessPartnerResult> validateBusinessPartner(
    BusinessPartnerRequest request,
  ) =>
      // `submitToSap` stays true: the point of a dry run is to exercise the
      // SAP path. `Commit: false` is what makes it a dry run — with
      // `submitToSap: false` the middleware would park the record and answer
      // without asking SAP anything, which validates nothing.
      _send(request.copyWith(commit: false, submitToSap: true));

  ResultFuture<BusinessPartnerResult> _send(
    BusinessPartnerRequest request,
  ) async {
    // Refused here rather than at the datasource so a queued replay is caught
    // too. A record without a sales area is accepted by the endpoint and then
    // cannot be delivered to SAP, so the rep would be told it worked and HQ
    // would find it stuck.
    if (!request.isRegisterable) {
      return const Left(
        ApiFailure(
          message: 'Registration is missing its name or sales area',
          statusCode: 422,
        ),
      );
    }

    try {
      final result = await _remote.createBusinessPartner(
        BusinessPartnerRequestModel.fromEntity(request),
      );

      // SAP's business rejection arrives as HTTP 200 with error rows. Mapped
      // to a Left so the bloc has one failure path, and carrying SAP's own
      // wording — the rep can act on "payment term T015 not defined for sales
      // organisation 0003" and cannot act on "submission failed".
      if (result.hasError) {
        return Left(
          ApiFailure(
            message: result.primaryMessage ?? 'SAP rejected the registration',
            statusCode: 422,
          ),
        );
      }

      // Committed, no errors, but no number: the middleware accepted the
      // record without SAP creating one. Treated as a failure because
      // returning success would let the wizard start uploading documents
      // against an id that does not exist.
      if (request.commit && !result.isCreated) {
        return const Left(
          ApiFailure(
            message: 'SAP returned no customer number',
            statusCode: 502,
          ),
        );
      }

      return Right(result);
    } on ServerException catch (e) {
      return Left(ApiFailure.fromException(e));
    }
  }
}
